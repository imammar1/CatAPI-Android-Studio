package com.example.newprojectp3.ui.main

import android.content.Context
import android.util.Log
import com.android.volley.Request
import com.android.volley.toolbox.JsonArrayRequest
import com.android.volley.toolbox.Volley
import com.google.gson.Gson

object CatBreedsRepository {
    private const val API_KEY = "live_7ZNJH7nl1t3KSJUDYPHKZ6hbNcuz3wdl5jDv4W9bF25PgNYnQ4RVvxsyIoIUYkmQ"
    private const val BASE_URL = "https://api.thecatapi.com/v1"

    fun fetchCatBreeds(context: Context, callback: (List<CatBreed>) -> Unit) {
        val queue = Volley.newRequestQueue(context)
        val url = "$BASE_URL/breeds?api_key=$API_KEY"

        val jsonArrayRequest = JsonArrayRequest(
            Request.Method.GET, url, null,
            { response ->
                val catBreeds = Gson().fromJson(response.toString(), Array<CatBreed>::class.java).toList()
                callback(catBreeds)
            },
            { error ->
                Log.e("CatBreedsRepository", "Error fetching cat breeds: ${error.message}")
            }
        )
        queue.add(jsonArrayRequest)
    }

    fun fetchCatBreedImage(context: Context, breedId: String, callback: (String) -> Unit) {
        val queue = Volley.newRequestQueue(context)
        val url = "$BASE_URL/images/search?api_key=$API_KEY&breed_ids=$breedId"

        val jsonArrayRequest = JsonArrayRequest(
            Request.Method.GET, url, null,
            { response ->
                val imageUrl = response.getJSONObject(0).getString("url")
                callback(imageUrl)
            },
            { error ->
                Log.e("CatBreedsRepository", "Error fetching cat breed image: ${error.message}")
            }
        )
        queue.add(jsonArrayRequest)
    }
}