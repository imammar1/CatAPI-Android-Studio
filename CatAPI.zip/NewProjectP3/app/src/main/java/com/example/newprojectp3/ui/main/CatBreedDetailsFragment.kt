package com.example.newprojectp3.ui.main

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import com.example.newprojectp3.databinding.FragmentCatBreedDetailsBinding
import com.squareup.picasso.Picasso


class CatBreedDetailsFragment : Fragment() {
    val viewModel: MainViewModel by viewModels()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val binding = FragmentCatBreedDetailsBinding.inflate(inflater, container, false)

        viewModel.selectedCatBreed.observe(viewLifecycleOwner) { catBreed ->
            // Update the views with the selected cat breed information
            binding.catBreedName.text = catBreed.name
            binding.catBreedOrigin.text = catBreed.origin
            binding.catBreedTemperament.text = catBreed.temperament

            // Load the cat breed image into the ImageView
            CatBreedsRepository.fetchCatBreedImage(requireContext(), catBreed.id) { imageUrl ->
                Picasso.get()
                    .load(imageUrl)
                    .into(binding.catBreedImage)
            }
        }

        binding.loadMoreButton.setOnClickListener {
            viewModel.selectedCatBreed.observe(viewLifecycleOwner) { catBreed ->
                CatBreedsRepository.fetchCatBreedImage(requireContext(), catBreed.id) { imageUrl ->
                    Picasso.get()
                        .load(imageUrl)
                        .into(binding.catBreedImage)
                }
            }
        }
            return binding.root
    }
}