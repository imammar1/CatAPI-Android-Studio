package com.example.newprojectp3.ui.main

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import com.example.newprojectp3.R
import com.example.newprojectp3.databinding.FragmentCatBreedsBinding

class CatBreedsFragment : Fragment() {
    private val viewModel: MainViewModel by viewModels()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val binding = FragmentCatBreedsBinding.inflate(inflater, container, false)

        viewModel.fetchCatBreeds(requireContext())
        viewModel.catBreeds.observe(viewLifecycleOwner) { catBreeds ->
            // Update the spinner with the cat breed names
            val breedNames = catBreeds.map { it.name }
            val adapter = ArrayAdapter(requireContext(), android.R.layout.simple_spinner_item, breedNames)
            binding.spinner.adapter = adapter
        }

        binding.spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>, view: View?, position: Int, id: Long) {
                val selectedBreedName = parent.getItemAtPosition(position) as String
                val catBreeds = viewModel.catBreeds.value ?: emptyList()
                val selectedBreed = catBreeds.find { it.name == selectedBreedName }
                viewModel.selectedCatBreed.value = selectedBreed

                val detailsFragment = requireActivity().supportFragmentManager.findFragmentById(R.id.details_container) as? CatBreedDetailsFragment
                detailsFragment?.viewModel?.selectedCatBreed?.value = selectedBreed
            }

            override fun onNothingSelected(parent: AdapterView<*>) {
                // Do nothing
            }
        }
        return binding.root
    }
}
