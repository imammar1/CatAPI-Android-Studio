package com.example.newprojectp3

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.newprojectp3.ui.main.CatBreedDetailsFragment
import com.example.newprojectp3.ui.main.CatBreedsFragment
import com.example.newprojectp3.ui.main.MainFragment

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val catBreedsFragment = CatBreedsFragment()
        supportFragmentManager.beginTransaction()
            .replace(R.id.container, catBreedsFragment)
            .commit()

        val catBreedDetailsFragment = CatBreedDetailsFragment()
        supportFragmentManager.beginTransaction()
            .replace(R.id.details_container, catBreedDetailsFragment)
            .commit()
    }
}
