package com.example.newprojectp3.ui.main

import android.content.Context
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class MainViewModel : ViewModel() {
    val catBreeds = MutableLiveData<List<CatBreed>>()
    val selectedCatBreed = MutableLiveData<CatBreed>()
    private val repository = CatBreedsRepository

    fun fetchCatBreeds(context: Context) {
        repository.fetchCatBreeds(context) { catBreedsList ->
            catBreeds.value = catBreedsList
        }
    }

    fun fetchCatBreedImage(context: Context, breedId: String) {
        repository.fetchCatBreedImage(context, breedId) { imageUrl ->
            selectedCatBreed.value?.imageUrl = imageUrl
        }
    }
}
