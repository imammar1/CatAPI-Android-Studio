package com.example.newprojectp3.ui.main

data class CatBreed(
    val id: String,
    val name: String,
    val origin: String,
    val temperament: String,
    var imageUrl: String?
)